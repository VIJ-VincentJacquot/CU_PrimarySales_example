// Import the checkout module from the Immutable SDK package
import { checkout } from '@imtbl/sdk';

// Instantiate the Checkout SDKs with the default configurations
export const checkoutSDK = new checkout.Checkout();